# API / STORAGE / MOBILE CONTRACT — DESIGN
**Status:** Proposed; storage commit and durability need Windows POC.

## 1. API conventions
- Prefix `/api/v1` ; JSON requests/responses; consistent status + error shape `{code,message,requestId,details?}` with details sanitized.
- Mutations require idempotency key and entity version (e.g., If-Match or body expectedVersion) where concurrent edits possible.
- Read endpoints: paging, sorting, filters, permitted data scope; no unconstrained full-scan.
- `GET /api/v1/system/connectivity`: a light endpoint; auth/session verification separately; timeout and retry policy.
- `GET /api/v1/modules`: server-authorized list of modules; metadata used by home navigation.
- `GET/PUT /api/v1/admin/module-rights`: Admin only, preconditions for changes, audit.
- `GET /api/v1/assets`, `GET /api/v1/workorders`, `GET /api/v1/inventory`: illustrative names, not locked endpoint contracts.
- Server enforces request size, file types, upload quotas, input schema, CSRF/session protections and rate limits where appropriate.

## 2. JSONL persistence
- JSON config; append-only immutable event journal with eventId, transactionId, schemaVersion, actorId, timestamp, entityId, entityVersion, eventType, payload.
- Serialized writer controls writes; distinguish *written*, *committed*, *durable* and *acknowledged* states. Do not assume file append is ACID.
- Multi-entity transaction protocol needs explicit prepare/commit/recovery or equivalent atomic journal design; projections rebuildable, not independent source of truth.
- Recovery detects torn trailing line, invalid schema, duplicate transactionId, mismatch snapshots, disk-full and locking conflicts. Never silently discard committed events.
- Retention/compaction must preserve audit and historical traceability; backups consistent and verified on isolated restore environment.
- Attachment files need content hash, size limit, MIME checks and transaction/reference lifecycle; exclude secrets and Production backup from cloud.

## 3. Sample event (illustrative)
```json
{"eventId":"uuid","transactionId":"uuid","schemaVersion":1,"entityType":"workOrder","entityId":"WO-XXXX","eventType":"WO_ASSIGNED","entityVersion":3,"occurredAt":"2026-11-10T08:30:00+07:00","actorId":"USER-ID","payload":{"assigneeId":"USER-ID"}}
```

## 4. PC and mobile HTTP LAN
- Android Chrome + iOS Safari, online-only over Wi-Fi LAN (LAN reachable, not necessarily Internet). No offline writes/sync, no service-worker feature claim.
- A lost response after POST is `UNKNOWN`, not automatically failed: check by idempotency key on reconnection.
- OS camera QR scan URL → deep link; browser camera streaming over HTTP LAN not assumed supported.
- HTTP does not encrypt credentials/cookies; Production security risk requires IT sign-off / mitigation. Internal HTTPS remains technical option but not adopted without owner decision.

## 5. G1 proof obligations
- At least 50 simulated concurrent clients as proposed benchmark (adjust after capacity planning); track latency p50/p95/p99, throughput, errors, CPU/RAM, journal size.
- Forced process crash at every commit stage, torn write, disk full, access denied, parallel writer prevention, backup while live and full restore.
- Validate zero lost committed records, zero duplicate acknowledged commands, stable entity versions; test documented RPO/RTO once set.
