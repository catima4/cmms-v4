# G0 — MASTER ARCHITECTURE & DESIGN DECISIONS
**ID:** CMMS-V4-G0 | **Revision:** 0.1.0 | **Date:** 2026-11-10 | **Status:** DESIGN DRAFT, not approved for implementation

## 1. Sứ mệnh và phạm vi
Xây CMMS v4 mới, không cập nhật tại chỗ v2. V2 là baseline tham chiếu chức năng và kỹ thuật; v3 v1.3 là nguồn quyết định nghiệp vụ có điều kiện. Phát triển trên Codex Cloud, GitHub Private, Windows CI; chạy Production trên Windows LAN sau nghiệm thu. Không đưa bí mật/dữ liệu Production lên cloud.

## 2. Các quyết định do chủ dự án đã lựa chọn
- Backend PowerShell; ưu tiên PowerShell 7 nhưng cần POC trên hệ điều hành Windows mục tiêu.
- JSON cấu hình; JSONL cho journal/audit; một Storage Engine trung tâm có transaction/recovery rõ ràng.
- Một server HTTP LAN; không có server tách riêng cho từng TAB.
- Multi-Page Modular Monolith: `home.html` điều hướng; mỗi nghiệp vụ có HTML/CSS/JS/PowerShell/schema/test/manifest riêng.
- Các trang có core chung: auth, UI shell, i18n VI/EN, API client, diagnostics; không nhân bản Core.
- Tài khoản User, Executor, Admin. Admin sở hữu giao diện ma trận quyền module 0–3 và ngoại lệ người dùng, phạm vi dữ liệu, audit.
- Mobile Android Chrome / iPhone Safari, Mobile Web responsive, Wi-Fi nội bộ, HTTP, chung API; online-only. Khi mất khả năng kết nối server: cảnh báo + vô hiệu hóa nghiệp vụ; không offline queue, không sync.
- Microsoft 365 chưa triển khai, chỉ giữ ranh giới adapter tương lai.
- Dashboard tổng hợp đầy đủ làm cuối; trang chủ định tuyến cần có sớm.
- Release Git commit/tag + ZIP có manifest/checksum/test report; không đóng gói Production data/credentials.

## 3. Context và ranh giới
PC Browser → `home.html` → `modules/<id>/web/<id>.html`; Mobile Browser → mobile shell / mobile views → **cùng `/api/v1`** → API Router trong một PowerShell process → service nghiệp vụ → Storage Engine → JSONL, snapshot, attachments. Admin Local Operations dùng bề mặt riêng, cần kiểm soát chỉ localhost/quyền hệ điều hành.

## 4. Ràng buộc kiến trúc
1. Giao diện không truy cập file JSONL trực tiếp.
2. Không module nào tự sửa ledger của module khác.
3. Mỗi module có ownership; liên thông qua contract use-case/API/service, tránh cross-module import tùy ý.
4. Route tài nguyên HTML lẫn API đều phải kiểm quyền phù hợp; không coi menu ẩn là bảo mật.
5. Core kiểm tra authentication, authorization, input validation, requestId, idempotency, concurrency, audit.
6. Các giao dịch liên đối tượng phải có commit semantics, crash recovery và đối chiếu tính toàn vẹn.
7. Security trên HTTP: không tuyên bố an toàn Production; cần threat assessment, IT sign-off, LAN segmentation, bảo vệ phiên, TLS migration option ghi nhận nhưng không tự triển khai.
8. Thời gian server UTC có offset khi hiển thị; event có id, schemaVersion, actorId, entityVersion.
9. English/Vietnamese labels phải quản lý tập trung, không nhúng bản dịch rời rạc.
10. Không áp dụng nâng cấp Production tự động.

## 5. Cây module mục tiêu
- Core/System, MasterData, Assets, Requests, WorkOrders, Planning, PreventiveMaintenance, Checklist, People, Inventory, Contractors, Costs, Approvals, Notifications, Reporting, Home/Dashboard.
- Module nghiệp vụ ưu tiên P0: Core/System, MasterData, Assets, Requests, WorkOrders; P1: Planning, PM, Checklist, People, Inventory, Contractors, Approvals, Notifications, Reporting; P2: Costs theo độ sẵn dữ liệu. Dashboard KPI cuối.
- Từ góc nhìn UX, 1 TAB có thể có nhiều view; không ép 1 view = 1 module.

## 6. Các quyết định *chưa* được khóa
- Máy chủ Windows và PowerShell 7, công suất client/WO/ngày, dữ liệu đính kèm, RPO/RTO, ERP là owner kho hay không, ma trận role mặc định, workflow WO chính xác, chính sách Viewer 24 giờ, vị trí gắn adapter notification, IT chấp nhận rủi ro HTTP.
- Không cho Codex lấp các mục này bằng giả định rồi tuyên bố đã phê duyệt.

## 7. Quy tắc nghiệm thu
G0 chỉ PASS khi có traceability mapping v2 P0/P1, module/API/RBAC/data contracts, threat/risk list, evidence plan và chủ dự án xác nhận. POC thực thi do Gate sau thực hiện; G0 không được gán PASS runtime.
