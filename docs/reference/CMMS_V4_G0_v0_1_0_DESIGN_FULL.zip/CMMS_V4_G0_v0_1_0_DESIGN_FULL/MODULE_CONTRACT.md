# MODULE CONTRACT — MPA + PowerShell Modular Monolith
**Status:** Proposed interface, subject to G0 approval.

## 1. Folder standard
```
modules/<module-id>/
  module.json
  web/<module-id>.html
  web/<module-id>.js
  web/<module-id>.css
  web/locales/vi.json
  web/locales/en.json
  server/<Module>.Api.ps1
  server/<Module>.Service.ps1
  server/<Module>.Repository.ps1
  schemas/
  tests/
```
Module phải khai báo id bất biến, version, entryPage, apiBase, supportedRoles (không phải quyền thực tế), permission levels, exceptional actions, data ownership, dependencies, migrations. Core đọc manifest khi startup, validate whitelist, reject duplicate IDs/routes; không đọc manifest do client gửi để cấp quyền.

## 2. Giao diện
- Home: thông tin tối thiểu về người dùng, nhà máy/ca, thông báo và link module theo quyền; không nạp toàn bộ module JS ở trang chủ.
- Mỗi trang HTML dùng shared shell (menu, navbar, localization, notifications, error handling) được version hóa và phát hành kiểm soát.
- Module code không gắn vào global DOM hoặc sửa file HTML của module khác.
- Có direct URL, deep links `/assets/detail.html?id=...`, 403 và 404 rõ ràng.
- Mobile Web: một thiết kế responsive hoặc view mobile riêng, nhưng dùng chung API; không có offline queue/cache nghiệp vụ.
- Mọi nút ghi disable khi connectivity probe thất bại; kết quả request bị ngắt được báo UNKNOWN và tra lại theo requestId sau reconnect.

## 3. Ví dụ manifest (minh họa, chưa hợp đồng cuối)
```json
{
  "id":"inventory", "version":"0.1.0", "entryPage":"/modules/inventory/web/inventory.html",
  "apiBase":"/api/v1/inventory", "dependencies":["core","master-data"],
  "dataOwner":"inventory", "defaultAccess":0,
  "specialActions":["inventory.adjust_stock","inventory.approve_issue"]
}
```

## 4. Liên thông
- WorkOrders → Inventory: yêu cầu ghi nhận vật tư qua Inventory Service; Inventory xử lý số lượng và ledger. WO chỉ nhận receipt/status/ref.
- Assets → WO: WO chứa assetId tham chiếu, không được sửa bản ghi Asset.
- PM → WO: tạo WO theo idempotency key; no duplicate when scheduler reruns.
- Kho & ERP: cần xác định system-of-record trước khi có stock ledger chính thức.

## 5. Version và nâng cấp
Semantic module version; breaking API/schema cần migration/compatibility tests. Một module thay UI không được làm thay đổi hợp đồng API. Codex PR phải nêu phạm vi file, regression impacted, migration, rollback và change log.
