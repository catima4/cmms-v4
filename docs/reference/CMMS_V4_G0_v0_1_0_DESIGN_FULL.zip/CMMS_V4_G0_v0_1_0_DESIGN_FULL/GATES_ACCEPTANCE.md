# G0.0–G8 — GATES / ACCEPTANCE PLAN
**Evidence status at package creation:** G0 materials DRAFT; every v4 runtime test = NOT RUN.

| Gate | Outputs | Acceptance / stop condition |
|---|---|---|
| G0.0 Cloud Foundation | private repo, branch protection, AGENTS.md, CI workflows, release pipeline, baseline docs | verify on GitHub, Windows CI executes and produces artifact; NO Production deployment |
| G0 Architecture | signed architecture, owner decisions, module/RBAC/API/storage contract, parity map | owner approves design; unresolved risks explicitly recorded |
| G1 Server & Storage | HTTP server/router, JSONL engine, recovery, backup, health | concurrency/crash/disk-full/restore tests pass on Windows; if fail reconsider storage |
| G2 Identity & Admin RBAC | 3 account types, session, admin rights matrix UI, audit, data scope | deny by default, per-module 0–3 tests, override, revoke, scope isolation |
| G3 Master Data / Assets | taxonomy, plants, asset registry/detail | traceability against v2 asset use cases |
| G4 Requests / WO | requests, lifecycle, contractor waiting, downtime, safe close | 100% P0 v2 parity, maintenance/production/EHS UAT |
| G5 Planning / PM / Checklist | schedule and PM tasks, field checklists | due-date/calendar/timezone, permissions, repeat trigger tests |
| G6 Inventory / Contractors / Approvals / Costs | stock owner rules, ledger, contractor workflow, targeted approvals | warehouse/ERP sign-off, stock ledger audit, SoD, high-risk UAT |
| G7 Notifications / Reporting | in-app notices, exports, KPI | synthetic notifications, source data accuracy, permissions, PDF/XLSX |
| G8 Dashboard / LAN Pilot | dashboard, production readiness, restore/rollback and mobile cross-browser test | pilot evidence, security sign-off, release approval |

## Universal Gate artifacts
- Design/change description + repository commit SHA.
- Test report: PASS/FAIL/NOT RUN per case with environment, timestamp, evidence path; NEVER claim unexecuted tests pass.
- Release manifest, checksum, ZIP integrity test, rollback plan, data migration policy and approval record.
- No silent modifications to V2; no secrets, personal or Production data uploaded.

## Production blockers
1. Unresolved HTTP credential/session threat without IT sign-off.
2. JSONL recovery/concurrency failure.
3. Missing v2 P0 parity or unapproved P1 gaps.
4. No restore validation and rollback drill.
5. Missing business owners for high-risk WO and inventory rules.
