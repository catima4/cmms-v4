# RBAC — Admin Module Permission Matrix
**G0-RBAC-001/002; owner decision:** Bảng quyền theo từng TAB thuộc Admin.

## 1. Role, level, scope
Role account: USER / EXECUTOR / ADMIN. Levels module: 0=DENY, 1=VIEW, 2=OPERATE, 3=MANAGE. Scope độc lập: site/factory, area, department, optional owned/assigned record. Level 3 không tự động mở thao tác có rủi ro cao.

## 2. Admin UI
- `Admin > Quản lý phân quyền`: bảng hàng = module registry, cột = User/Executor/Admin, mỗi ô select 0/1/2/3; hiển thị default role policy.
- Tab `Ngoại lệ cá nhân`: chọn user, xem quyền hiệu lực (role default → override), phạm vi dữ liệu, lý do, thời hạn nếu có.
- Tab `Lịch sử quyền`: actor, target, before/after, timestamp, reason, requestId; chỉ đọc, không sửa audit.
- Thao tác Save bắt buộc confirm + validation server + atomic storage; đáp ứng nguyên tắc không lockout quản trị.
- Module mới tự hiện hàng mới, `defaultAccess=0` đối với tất cả tài khoản trước khi được phê duyệt.

## 3. Ma trận gốc
Chưa phê duyệt giá trị mặc định! Các giá trị ở demo hội thoại chỉ là minh họa, KHÔNG dùng làm default Production. Core phải có ít nhất một tài khoản bootstrap admin được kiểm soát, không lưu mật khẩu trong source/release.

## 4. Hành động ngoại lệ
- WO.APPROVE / WO.RETURN_TO_SERVICE: tách thẩm quyền ký, separation of duties theo criticality.
- INVENTORY.ADJUST / ISSUE.APPROVE: kiểm soát ledger và tính trách nhiệm.
- SYSTEM.PERMISSIONS.MANAGE / AUDIT.READ / BACKUP.RESTORE: quyền bảo mật riêng, thường chỉ Admin/IT.
- Dù role Admin, nghiệp vụ phê duyệt an toàn không tự động được cấp.

## 5. Evaluation & protection
Effective permission = deny by default + authenticated identity + module level + special action policy + data scope + state/business checks. Mọi request API kiểm tra lại server side, revoke effect theo request mới; không tin claims client gửi. 403 với requestId, log audit phù hợp nhưng không rò thông tin.

## 6. User test set
1. User quyền 0 không thấy tile, direct URL và API đều không truy cập được.
2. View level 1 không tạo/cập nhật kể cả gọi API thủ công.
3. Operate level 2 không chỉnh inventory adjustment hoặc nghiệm thu an toàn nếu thiếu special action.
4. Áp dụng override cho 1 Executor không ảnh hưởng người khác.
5. Scope factory A không truy cập factory B qua thay ID.
6. Revoke khi session còn tồn tại có hiệu lực tại request kế tiếp.
7. Mọi đổi quyền có audit before/after.
8. Admin không thể tự khóa toàn bộ khả năng quản trị.
