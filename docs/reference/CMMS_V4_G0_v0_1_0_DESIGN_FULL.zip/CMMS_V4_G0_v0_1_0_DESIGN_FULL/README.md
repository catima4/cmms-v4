# CMMS V4 — G0 Master Architecture v0.1.0 (DESIGN_FULL)
Ngày: 2026-11-10 | Trạng thái: DRAFT / AWAITING OWNER APPROVAL

Đây là hồ sơ G0 thiết kế, không phải phần mềm vận hành, không tuyên bố test PASS runtime. Dùng để giao Codex Cloud làm G0.0 và hoàn thiện G0, không cho phép Codex tự chuyển G1/Production.

## Phạm vi
- Dựa trên quyết định người dùng về v4: PowerShell + JSON/JSONL, HTTP LAN, MPA HTML theo module, phân quyền Admin theo module, mobile web Android/iOS online-only, Codex Cloud + GitHub Private + Windows Actions.
- Đối chiếu ở mức mã nguồn/đóng gói v2 M16.1 v2.0.0.2 và tài liệu lựa chọn v3 v1.3. Chưa xác minh runtime v2 trên máy nhà máy.
- Không tự động tích hợp Microsoft 365, không sao chép dữ liệu sản xuất, không triển khai Production.

## Tài liệu
1. G0_MASTER_ARCHITECTURE.md: kiến trúc và quyết định.
2. MODULE_CONTRACT.md: contract module và màn hình HTML.
3. RBAC_ADMIN_MATRIX.md: chính sách phân quyền và quản trị.
4. API_STORAGE_CONTRACT.md: API/data/transaction/backup.
5. V2_V3_PARITY_MATRIX.md: kế thừa, khác biệt, việc cần kiểm chứng.
6. GATES_ACCEPTANCE.md: kế hoạch, điều kiện nghiệm thu.
7. CODEX_HANDOFF_READ_ONLY.md: yêu cầu cho Codex G0.0.
8. RELEASE_MANIFEST.json, SHA256SUMS.txt.

## Cảnh báo G0
HTTP LAN giữ theo yêu cầu chủ dự án nhưng không mã hóa lưu lượng; cần đánh giá và chấp nhận rủi ro trước Production. Mobile Web trên HTTP LAN không được cam kết PWA chuẩn, offline, Service Worker hay camera trong trang. JSONL phải qua POC về ghi đồng thời và phục hồi trước sử dụng thực tế.
