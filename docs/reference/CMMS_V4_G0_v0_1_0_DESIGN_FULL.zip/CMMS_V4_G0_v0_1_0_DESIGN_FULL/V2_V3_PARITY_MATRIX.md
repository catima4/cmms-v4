# V2/V3 → V4 TRACEABILITY MATRIX
**Evidence class:** V2 ZIP inspected at archive/content level; no live factory runtime test. V3 docx is a design choice document, not implemented V3 source.

| Source | Observed / documented component | V4 decision | Proof still required |
|---|---|---|---|
| V2 | `server/Start-CMMS-M1.ps1` main server | Keep one PowerShell process; separate router/startup | HTTP LAN, restart, concurrent clients |
| V2 | `web/index.html` and versioned `web/*.js` | Replace UI coupling with per-module HTML/JS | parity screenshots, navigation, accessibility |
| V2 | `server/CMMS.Auth.ps1` | Rebuild common auth/RBAC, 3 roles | role migration, session security |
| V2 | `server/CMMS.Data.ps1`, `server/CMMS.Writer.ps1` | Audit and preserve working lock/concurrency logic where verified | crash recovery, durability |
| V2 | `server/CMMS.M13.WO.ps1`, `.M13.SLA.ps1` | Map existing WO lifecycle and SLA | 100% P0 flow / P1 exceptions |
| V2 | `server/CMMS.B8.Reporting.ps1`, `.B8.Pdf.ps1` | Dedicated reporting module | PDF/XLSX parity/permissions |
| V2 | `admin-ops/` with own HTML/PS | Preserve isolated operational surface | authenticated local access, backup/restore |
| V2 | `server/CMMS.M16.Notification.ps1` and README | Keep best-effort queue semantics; no live M365 | synthetic regression, no fake live status |
| V3 1.3 | G0 multi-site, scope, bilingual, audit | Adopt where applicable | business owner approval |
| V3 1.3 | G5 WO, downtime separate, safety approval, contractor visibility | Adopt as design candidates with V2 parity | production + maintenance + EHS UAT |
| V3 1.3 | G10 ERP system-of-record, stock ledger | Conditional: decide owner first | ERP and warehouse signoff |
| V3 1.3 | G13 minimal workflow engine, delegated approval | Adopt scoped rules, avoid generic engine | approval & segregation UAT |
| V3 1.3 | G18 dashboard last | Keep target dashboard last | metrics source verified |
| V3 1.3 | M365 integrations parked | No production integration | architecture adapter only |

## P0/P1 parity protocol
For each V2 capability: ID, use-case, actors, preconditions, inputs, transitions, output, API/HTML source evidence, test fixture, expected result and v4 test result (NOT RUN by default). No parity is assumed PASS based on code listing or prior chat. P0 pass requires actual Windows/LAN proof; P1 exceptions need written owner acceptance before Production.

## Evidence limitations
V2 archive integrity only confirms ZIP readable; no claim live server functions or all v2 use cases PASS in this review. The v2 README explicitly says M16.1 synthetic transports only (no real Mail/Teams). V3 v1.3 is conditional architecture, not an implemented codebase.
