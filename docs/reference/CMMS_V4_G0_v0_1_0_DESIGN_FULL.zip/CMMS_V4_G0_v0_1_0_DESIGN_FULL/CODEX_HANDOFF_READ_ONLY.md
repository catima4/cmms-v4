# CODEX CLOUD HANDOFF — G0.0 / FOUNDATION ONLY
**Owner approval required before execution of any implementation beyond Foundation.**

## Inputs
This DESIGN_FULL zip; optionally V2 baseline ZIP (READ ONLY) and V3 design docx, only if approved for external cloud repository/cloud workspace. Never upload real Production data, passwords, private identities, mailbox tokens or network secrets.

## Task boundary
1. Initialize a **private** GitHub repository only after user authorizes action; create `AGENTS.md`, `.gitignore`, `docs/`, `modules/` skeleton, `.github/workflows/` Windows CI, version and release scripts.
2. Create minimal `home.html`, `assets.html`, `inventory.html` *placeholder shell* with shared UI/core and module registration; no business CRUD, no V2 code modifications.
3. Implement test harness samples and deterministic release ZIP/manifest/checksum pipeline. Use Git tags as immutable provenance.
4. Provide tests on available environment; mark Windows GitHub CI NOT RUN until actual Actions evidence exists. Cloud task cannot assert LAN/firewall/mobile physical PASS.
5. Produce exact list of file changes, proposed PR, tests + evidence, risk list, cloud cost implications and G0.0 release zip; stop for human approval.

## Non-goals
- No Work Order, Inventory stock, Production data, Microsoft 365, Internet-exposed CMMS, unattended production deployment or automatic next Gate.
- Do not assume a GitHub repo already exists or that CodeX has credentials/permissions.

## Mandatory terminal response
Gate status (PASS/FAIL/NOT RUN), commit SHA/PR URL if actually created, ZIP hash and verification, CI Windows run link if actually executed; unresolved design decisions; no false claims.
